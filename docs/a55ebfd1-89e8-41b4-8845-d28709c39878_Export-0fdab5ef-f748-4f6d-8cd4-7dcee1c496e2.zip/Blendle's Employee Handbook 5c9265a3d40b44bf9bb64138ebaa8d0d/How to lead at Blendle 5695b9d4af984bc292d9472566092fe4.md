# How to lead at Blendle

This section is dedicated to all the people who are in some way in a lead role. This will give you  all the info, context, background, tools, processes and frameworks you need to lead. This should equip you to make decisions. This doesn't mean your are on your own in this. Please ask for help.

Before you dig in, read this piece (with 6 must reads in it).

[Our 6 Must Reads for First-Time Managers to Hit the Ground Running](http://firstround.com/review/our-6-must-reads-for-first-time-managers-to-hit-the-ground-running/)

---

[Your check-list](Your%20check-list%20a43d735b01c546bb9407859b16ab88eb.md)

---

[Leading Feedback ](Leading%20Feedback%20626e81fe657947eeb6dfdca22c16f766.md)

[Salary talks](Salary%20talks%206234be42d5d4411ca0188b3dd8b5374b.md)

[Hiring ](Hiring%20b94feed272744aba96a97fced6c631be.md)

[Firing](Firing%20d0bd9a43f9ec4f4ca17bead33b27ea61.md)

[Party and study budget](Party%20and%20study%20budget%20b7943bcc66194540b9b497497647edbe.md)

[Holidays](Holidays%203265daed19714ea6a14718df28fe3596.md)

[Personal User Guide](Personal%20User%20Guide%2031253cf70294478e92e3293d88fb4a2e.md)

[Soft shizzle](Soft%20shizzle%204d7ce36f33b54d3790c0112b2754c54c.md)

[Sickness absence](Sickness%20absence%20cdc8d25d24f44bb98718220a3c977d4c.md)

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).