# #letstalkaboutstress

Let’s talk about stress. Too much stress. 

We know this can be a topic.

So let’s get this conversation going. 

[Intro: two things you should know](#letstalkaboutstress%205f7d3f26f1624fb99b259f6b8e1bfb49/Intro%20two%20things%20you%20should%20know%20a168e91a85614cc2a67a4422ce75f12d.md)

[What is stress](#letstalkaboutstress%205f7d3f26f1624fb99b259f6b8e1bfb49/What%20is%20stress%208d4c0c1b2e474e46b1b985eced0c1b20.md)

[When is there too much stress?](#letstalkaboutstress%205f7d3f26f1624fb99b259f6b8e1bfb49/When%20is%20there%20too%20much%20stress%202ad8c1537ecc464ea809c2f506b83489.md)

[What can I do](#letstalkaboutstress%205f7d3f26f1624fb99b259f6b8e1bfb49/What%20can%20I%20do%20749328e2ea6f4e32a8b224f2f64ea611.md)

[What can Blendle do?](#letstalkaboutstress%205f7d3f26f1624fb99b259f6b8e1bfb49/What%20can%20Blendle%20do%205839c39fa78e4d938044a713ba5af09d.md)

[Good reads](#letstalkaboutstress%205f7d3f26f1624fb99b259f6b8e1bfb49/Good%20reads%205bd251768fda406795d5888c2286d0c7.md)

Go to **#letstalkaboutstress** on slack to chat about this topic

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).